package com.example.ecologic.ui.utils

/**
 * Moved to https://google.github.io/accompanist/systemuicontroller/
 */
