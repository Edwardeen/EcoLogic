package com.example.ecologic.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.navigation
import com.example.ecologic.ui.home.HomeSections
import com.example.ecologic.ui.home.addHomeGraph
import com.example.ecologic.ui.navigation.MainDestinations
import com.example.ecologic.ui.navigation.rememberecologicNavController
import com.example.ecologic.ui.snackdetail.SnackDetail
import com.example.ecologic.ui.theme.ecologicTheme

@Composable
fun ecologicApp() {
    ecologicTheme {
        val ecologicNavController = rememberecologicNavController()
        NavHost(
            navController = ecologicNavController.navController,
            startDestination = MainDestinations.HOME_ROUTE
        ) {
            ecologicNavGraph(
                onSnackSelected = ecologicNavController::navigateToSnackDetail,
                upPress = ecologicNavController::upPress,
                onNavigateToRoute = ecologicNavController::navigateToBottomBarRoute
            )
        }
    }
}

private fun NavGraphBuilder.ecologicNavGraph(
    onSnackSelected: (Long, NavBackStackEntry) -> Unit,
    upPress: () -> Unit,
    onNavigateToRoute: (String) -> Unit
) {
    navigation(
        route = MainDestinations.HOME_ROUTE,
        startDestination = HomeSections.FEED.route
    ) {
        addHomeGraph(onSnackSelected, onNavigateToRoute)
    }
    composable(
        "${MainDestinations.SNACK_DETAIL_ROUTE}/{${MainDestinations.SNACK_ID_KEY}}",
        arguments = listOf(navArgument(MainDestinations.SNACK_ID_KEY) { type = NavType.LongType })
    ) { backStackEntry ->
        val arguments = requireNotNull(backStackEntry.arguments)
        val snackId = arguments.getLong(MainDestinations.SNACK_ID_KEY)
        SnackDetail(snackId, upPress)
    }
}
